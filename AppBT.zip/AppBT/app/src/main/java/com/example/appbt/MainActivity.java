package com.example.appbt;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.telephony.SmsManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;
import android.Manifest;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.content.Context;

public class MainActivity extends AppCompatActivity implements LocationListener {
    private static final int LOCATION_PERMISSION_CODE = 3;
    private LocationManager locationManager;
    private Location lastKnownLocation;
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final int REQUEST_ENABLE_BT = 1;
    private static final int SMS_PERMISSION_CODE = 2;

    private BluetoothSocket btSocket;
    private OutputStream outputStream;
    private String phoneNumber = "0986973307"; // Reemplaza con el número destino

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Verificar y solicitar permisos
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        checkLocationPermissions();
        checkPermissions();

        // Configurar Bluetooth
        BluetoothAdapter btAdapter = BluetoothAdapter.getDefaultAdapter();
        if (btAdapter == null) {
            Toast.makeText(this, "Bluetooth no soportado", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        if (!btAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        }

        // Conectar al ESP32
        Button connectBtn = findViewById(R.id.connectBtn);
        connectBtn.setOnClickListener(v -> connectToESP32());

        // Botón de prueba para enviar SMS
        Button testSmsBtn = findViewById(R.id.testSmsBtn);
        testSmsBtn.setOnClickListener(v -> sendSMS("Mensaje de prueba desde botón"));
    }

    private void checkLocationPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startLocationUpdates();
            } else {
                Toast.makeText(this, "Permiso de ubicación denegado", Toast.LENGTH_SHORT).show();
            }
        }
        // ... manejo de otros permisos ...
    }
    

    private void startLocationUpdates() {
        try {
            locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    10000,  // 10 segundos (en ms)
                    10,      // 10 metros (distancia mínima)
                    this);

            // Obtener última ubicación conocida
            lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        } catch (SecurityException e) {
            Toast.makeText(this, "Error de permisos de ubicación", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        lastKnownLocation = location;
    }

    // Implementa otros métodos requeridos por LocationListener
    @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
    @Override public void onProviderEnabled(String provider) {}
    @Override public void onProviderDisabled(String provider) {}


    private void checkPermissions() {
        // Verificar permiso de SMS
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        }

        // Verificar permisos de Bluetooth (para Android 12+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.BLUETOOTH_CONNECT},
                        REQUEST_ENABLE_BT);
            }
        }
    }

    private void connectToESP32() {
        new Thread(() -> {
            try {
                BluetoothAdapter btAdapter = BluetoothAdapter.getDefaultAdapter();
                BluetoothDevice device = btAdapter.getRemoteDevice("08:A6:F7:47:52:9E"); // MAC de tu ESP32

                btSocket = device.createRfcommSocketToServiceRecord(MY_UUID);
                btSocket.connect();
                outputStream = btSocket.getOutputStream();

                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Conectado a ESP32", Toast.LENGTH_SHORT).show());

                // Escuchar comandos
                listenForCommands();

            } catch (IOException e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Error de conexión: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private void listenForCommands() {
        new Thread(() -> {
            InputStream inputStream;
            try {
                inputStream = btSocket.getInputStream();
            } catch (IOException e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Error al obtener el flujo de entrada", Toast.LENGTH_SHORT).show());
                return;
            }

            byte[] buffer = new byte[1024];
            int bytes;

            while (true) {
                try {
                    // Leer datos del Bluetooth
                    bytes = inputStream.read(buffer);
                    if (bytes > 0) {
                        String message = new String(buffer, 0, bytes).trim();
                        Log.d("BT_MSG", "Mensaje recibido: " + message);

                        if (message.startsWith("SEND_SMS")) {
                            String[] parts = message.split(":");
                            String baseMessage = parts.length > 1 ?
                                    "¡Alerta! Objeto detectado a " + parts[1] + " cm" :
                                    "¡Alerta! Objeto detectado cerca";

                            runOnUiThread(() -> {
                                Toast.makeText(MainActivity.this,
                                        "Activando envío de SMS con ubicación", Toast.LENGTH_SHORT).show();
                                sendSMS(baseMessage);
                            });
                        }
                    }
                } catch (IOException e) {
                    Log.e("BT_ERROR", "Error en la conexión Bluetooth", e);
                    runOnUiThread(() -> {
                        Toast.makeText(MainActivity.this,
                                "Conexión Bluetooth perdida", Toast.LENGTH_SHORT).show();
                        // Opcional: intentar reconectar
                        connectToESP32();
                    });
                    break;
                }
            }
        }).start();
    }
    private Location getLastKnownLocation() {
        try {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) ==
                    PackageManager.PERMISSION_GRANTED) {

                LocationManager locationManager =
                        (LocationManager) getSystemService(Context.LOCATION_SERVICE);

                // Obtener última ubicación conocida
                Location location = locationManager.getLastKnownLocation(
                        LocationManager.GPS_PROVIDER);

                if (location == null) {
                    location = locationManager.getLastKnownLocation(
                            LocationManager.NETWORK_PROVIDER);
                }
                return location;
            }
        } catch (Exception e) {
            Log.e("LOCATION_ERROR", "Error obteniendo ubicación: " + e);
        }
        return null;
    }


    // Modifica el método sendSMS para incluir la ubicación
    private void sendSMS(String message) {
        new Thread(() -> {
            try {
                // Obtener ubicación en un hilo separado
                Location location = getLastKnownLocation();

                // Construir mensaje final
                String fullMessage = message;
                if (location != null) {
                    fullMessage += "\n\nUbicación: https://maps.google.com/?q=" +
                            location.getLatitude() + "," + location.getLongitude() +
                            "\nPrecisión: " + location.getAccuracy() + " metros";
                } else {
                    fullMessage += "\n\nUbicación: No disponible";
                }

                // Enviar SMS
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(
                        phoneNumber,
                        null,
                        fullMessage,
                        null,
                        null);

                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "SMS enviado correctamente", Toast.LENGTH_LONG).show());

            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Error al enviar SMS: " + e.getMessage(), Toast.LENGTH_LONG).show());
                Log.e("SMS_ERROR", "Error: " + e.getMessage());
            }
        }).start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (locationManager != null) {
            locationManager.removeUpdates(this);
        }
        try {
            if (btSocket != null) {
                btSocket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}